import { getAllLifecycleHooks } from '@angular/compiler/src/lifecycle_reflector';
import { Component } from '@angular/core';
import { SpaceXService } from './space-x.service';
import {Location} from '@angular/common'; 
@Component({
selector: 'app-root',
templateUrl: './app.component.html',
styleUrls: ['./app.component.scss']
})
export class AppComponent {
title = 'BacancyJeyanInterviewTask';
allData: any;
resultArray: any;
launchYear: any;
noDataTodisplay: boolean = false;
loading: boolean = false;
constructor(private spaceXservice : SpaceXService,
private location: Location){
}
ngOnInit() {
this.getAllData();
}
getAllData(){
this.loading = true;
this.spaceXservice.getAllDatas().subscribe(res =>{
this.allData = res;
this.resultArray = res;
this.loading = false;
});
}
filterByLaunchYear(year:any)
{
this.loading = true;
this.location.replaceState("/filterByLaunchYear/"+year+"");
this.spaceXservice.getDatasByYear(year).subscribe(res =>{
this.resultArray = res;
this.loading = false;
if(this.resultArray == ""){
this.noDataTodisplay = true;
}else{
this.noDataTodisplay = false;
}
});
}
filterBySuccessfullLaunch(trueOrFalse:boolean){
this.loading = true;
this.location.replaceState("/filterBySuccessfullLaunch/"+trueOrFalse+"");
this.spaceXservice.getDatasBySuccessfullLaunch(trueOrFalse).subscribe(res =>{
this.resultArray = res;
this.loading = false;
if(this.resultArray == ""){
this.noDataTodisplay = true;
}else{
this.noDataTodisplay = false;
}
});
}
filterBySuccessfullLanding(trueOrFalse:boolean){
this.loading = true;
this.location.replaceState("/filterBySuccessfullLanding/"+trueOrFalse+"");
this.spaceXservice.getDatasBySuccessfullLanding(trueOrFalse).subscribe(res =>{
this.resultArray = res;
this.loading = false;
if(this.resultArray == ""){
this.noDataTodisplay = true;
}else{
this.noDataTodisplay = false;
}
});
}
}